enum GestureAction { scrollUp, scrollDown, none }

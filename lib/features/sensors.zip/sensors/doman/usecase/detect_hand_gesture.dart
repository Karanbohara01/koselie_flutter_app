import 'package:koselie/features/sensors/doman/entity/gesture_action.dart';
import 'package:koselie/features/sensors/doman/repository/gesture_repository.dart';

class DetectHandGesture {
  final GestureRepository repository;

  DetectHandGesture(this.repository);

  Stream<GestureAction> execute() {
    return repository.detectHandGesture();
  }
}

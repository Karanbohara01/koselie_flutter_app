import 'package:koselie/features/sensors/doman/entity/gesture_action.dart';

abstract class GestureRepository {
  Stream<GestureAction> detectHandGesture();
}

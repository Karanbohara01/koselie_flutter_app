part of 'gesture_bloc.dart';

abstract class GestureEvent {}

class StartListening extends GestureEvent {}

class GestureDetected extends GestureEvent {
  final GestureAction action;
  GestureDetected(this.action);
}

part of 'gesture_bloc.dart';

abstract class GestureState {}

class GestureInitial extends GestureState {}

class GestureSuccess extends GestureState {
  final GestureAction action;
  GestureSuccess(this.action);
}

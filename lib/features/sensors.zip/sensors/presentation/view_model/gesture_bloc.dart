import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:koselie/features/sensors/doman/entity/gesture_action.dart';
import 'package:koselie/features/sensors/doman/usecase/detect_hand_gesture.dart';

part 'gesture_event.dart';
part 'gesture_state.dart';

class GestureBloc extends Bloc<GestureEvent, GestureState> {
  final DetectHandGesture detectHandGesture;

  GestureBloc(this.detectHandGesture) : super(GestureInitial()) {
    on<StartListening>((event, emit) {
      detectHandGesture.execute().listen((gesture) {
        if (gesture != GestureAction.none) {
          add(GestureDetected(gesture));
        }
      });
    });

    on<GestureDetected>((event, emit) {
      emit(GestureSuccess(event.action));
    });
  }
}

import 'package:koselie/features/sensors/data/gesture_data_source/gesture_data_source.dart';
import 'package:koselie/features/sensors/doman/entity/gesture_action.dart';
import 'package:koselie/features/sensors/doman/repository/gesture_repository.dart';

class GestureRepositoryImpl implements GestureRepository {
  final GestureSensorDataSource dataSource;

  GestureRepositoryImpl(this.dataSource);

  @override
  Stream<GestureAction> detectHandGesture() {
    bool lastState = false;
    return dataSource.proximityStream.map((isClose) {
      GestureAction action = GestureAction.none;

      if (isClose && !lastState) {
        action = GestureAction.scrollDown;
      } else if (!isClose && lastState) {
        action = GestureAction.scrollUp;
      }

      lastState = isClose;
      return action;
    });
  }
}

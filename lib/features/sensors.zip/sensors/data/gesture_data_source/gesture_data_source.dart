import 'dart:async';

import 'package:proximity_sensor/proximity_sensor.dart';

class GestureSensorDataSource {
  final StreamController<bool> _proximityController =
      StreamController<bool>.broadcast();

  GestureSensorDataSource() {
    ProximitySensor.events.listen((event) {
      _proximityController.add(event as bool);
    });
  }

  Stream<bool> get proximityStream => _proximityController.stream;
}

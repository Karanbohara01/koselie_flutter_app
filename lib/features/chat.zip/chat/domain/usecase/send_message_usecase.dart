import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:koselie/app/usecase/usecase.dart';
import 'package:koselie/core/error/failure.dart';
import 'package:koselie/features/chat/domain/entity/message_entity.dart';
import 'package:koselie/features/chat/domain/repository/message_repository.dart';

class SendMessageParams extends Equatable {
  final String token;
  final MessageEntity message;
  final String receiverId;

  const SendMessageParams({
    required this.token,
    required this.message,
    required this.receiverId,
  });

  // Updated Empty constructor without const
  SendMessageParams.empty()
      : token = '_empty_string',
        message = MessageEntity.empty(), // No const
        receiverId = '_empty_string';

  @override
  List<Object?> get props => [token, message, receiverId];
}

class SendMessageUseCase implements UsecaseWithParams<void, SendMessageParams> {
  final IChatRepository chatRepository;

  SendMessageUseCase({required this.chatRepository});

  @override
  Future<Either<Failure, void>> call(SendMessageParams params) async {
    return await chatRepository.sendMessage(
      params.token,
      params.message,
      params.receiverId,
    );
  }
}

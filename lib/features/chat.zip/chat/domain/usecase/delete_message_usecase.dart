import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:koselie/app/usecase/usecase.dart';
import 'package:koselie/core/error/failure.dart';
import 'package:koselie/features/chat/domain/repository/message_repository.dart';

class DeleteMessageParams extends Equatable {
  final String token;
  final String messageId;

  const DeleteMessageParams({
    required this.token,
    required this.messageId,
  });

  // Empty constructor
  const DeleteMessageParams.empty()
      : token = '_empty.string',
        messageId = '_empty.string';

  @override
  List<Object?> get props => [token, messageId];
}

class DeleteMessageUseCase
    implements UsecaseWithParams<void, DeleteMessageParams> {
  final IChatRepository chatRepository;

  DeleteMessageUseCase({required this.chatRepository});

  @override
  Future<Either<Failure, void>> call(DeleteMessageParams params) async {
    return await chatRepository.deleteMessage(
      params.token,
      params.messageId,
    );
  }
}

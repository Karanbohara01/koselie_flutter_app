import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import 'package:koselie/app/usecase/usecase.dart';
import 'package:koselie/core/error/failure.dart';
import 'package:koselie/features/chat/domain/entity/message_entity.dart';
import 'package:koselie/features/chat/domain/repository/message_repository.dart';

class GetMessagesParams extends Equatable {
  final String token;
  final String senderId;
  final String receiverId;

  const GetMessagesParams({
    required this.token,
    required this.senderId,
    required this.receiverId,
  });

  // Empty constructor
  const GetMessagesParams.empty()
      : token = '_empty.string',
        senderId = '_empty.string',
        receiverId = '_empty.string';

  @override
  List<Object?> get props => [token, senderId, receiverId];
}

class GetMessagesUseCase
    implements UsecaseWithParams<List<MessageEntity>, GetMessagesParams> {
  final IChatRepository chatRepository;

  // Use named parameters only for consistency
  GetMessagesUseCase({required this.chatRepository});

  @override
  Future<Either<Failure, List<MessageEntity>>> call(
      GetMessagesParams params) async {
    return await chatRepository.getMessages(
      params.token,
      params.senderId,
      params.receiverId,
    );
  }
}

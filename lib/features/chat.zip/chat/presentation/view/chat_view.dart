// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:koselie/features/chat/presentation/view_model/bloc/chat_bloc.dart';

// class ChatScreen extends StatefulWidget {
//   final String senderId;
//   final String receiverId;

//   const ChatScreen({
//     super.key,
//     required this.senderId,
//     required this.receiverId,
//   });

//   @override
//   _ChatScreenState createState() => _ChatScreenState();
// }

// class _ChatScreenState extends State<ChatScreen> {
//   final TextEditingController _controller = TextEditingController();

//   @override
//   void initState() {
//     super.initState();
//     final chatBloc = context.read<ChatBloc>();

//     // ✅ Load Messages (Both Sent & Received)
//     chatBloc.add(LoadMessagesEvent(
//       senderId: widget.senderId,
//       receiverId: widget.receiverId,
//     ));

//     // ✅ Ensure Token is Loaded
//     if (chatBloc.state.token == null) {
//       chatBloc.add(LoadTokenEvent());
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Chat with ${widget.receiverId.substring(0, 8)}..."),
//         backgroundColor: Colors.purple,
//       ),
//       body: BlocListener<ChatBloc, ChatState>(
//         listener: (context, state) {
//           if (state.error != null) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(
//                 content: Text(state.error!),
//                 backgroundColor: Colors.red,
//               ),
//             );
//           }
//         },
//         child: Column(
//           children: [
//             Expanded(
//               child: BlocBuilder<ChatBloc, ChatState>(
//                 builder: (context, state) {
//                   if (state.isLoading) {
//                     return const Center(child: CircularProgressIndicator());
//                   }

//                   if (state.messages.isEmpty) {
//                     return const Center(child: Text("No messages yet"));
//                   }

//                   return ListView.builder(
//                     reverse: false, // ✅ Show messages in natural order
//                     padding: const EdgeInsets.all(10),
//                     itemCount: state.messages.length,
//                     itemBuilder: (context, index) {
//                       final message = state.messages[index];
//                       final isSentByMe = message.senderId == widget.senderId;

//                       return Align(
//                         alignment: isSentByMe
//                             ? Alignment.centerRight
//                             : Alignment.centerLeft,
//                         child: Container(
//                           margin: const EdgeInsets.symmetric(
//                               vertical: 5, horizontal: 10),
//                           padding: const EdgeInsets.all(10),
//                           decoration: BoxDecoration(
//                             color:
//                                 isSentByMe ? Colors.purple : Colors.grey[800],
//                             borderRadius: BorderRadius.only(
//                               topLeft: const Radius.circular(10),
//                               topRight: const Radius.circular(10),
//                               bottomLeft: isSentByMe
//                                   ? const Radius.circular(10)
//                                   : Radius.zero,
//                               bottomRight: isSentByMe
//                                   ? Radius.zero
//                                   : const Radius.circular(10),
//                             ),
//                           ),
//                           child: Text(
//                             message.message,
//                             style: const TextStyle(color: Colors.white),
//                           ),
//                         ),
//                       );
//                     },
//                   );
//                 },
//               ),
//             ),

//             // ✅ Message Input Field
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Row(children: [
//                 Expanded(
//                   child: TextField(
//                     controller: _controller,
//                     decoration: InputDecoration(
//                       hintText: 'Type a message...',
//                       filled: true,
//                       fillColor: Colors.white10,
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(30),
//                         borderSide: BorderSide.none,
//                       ),
//                     ),
//                   ),
//                 ),
//                 IconButton(
//                   icon: const Icon(Icons.send, color: Colors.purple),
//                   onPressed: () {
//                     if (_controller.text.isNotEmpty) {
//                       final chatBloc = context.read<ChatBloc>();

//                       if (chatBloc.state.token == null) {
//                         ScaffoldMessenger.of(context).showSnackBar(
//                           const SnackBar(
//                             content: Text("Error: Token not available"),
//                             backgroundColor: Colors.red,
//                           ),
//                         );
//                         return;
//                       }

//                       // ✅ Add SendMessage event with token
//                       chatBloc.add(
//                         SendMessage(
//                           senderId: widget.senderId,
//                           receiverId: widget.receiverId,
//                           message: _controller.text,
//                           token: chatBloc
//                               .state.token!, // ✅ Include token from state
//                         ),
//                       );

//                       _controller.clear();

//                       // ✅ Refresh messages after sending
//                       chatBloc.add(
//                         LoadMessagesEvent(
//                           senderId: widget.senderId,
//                           receiverId: widget.receiverId,
//                         ),
//                       );
//                     }
//                   },
//                 ),
//               ]),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:koselie/features/chat/domain/entity/message_entity.dart';
// import 'package:koselie/features/chat/presentation/view_model/bloc/chat_bloc.dart';

// class ChatScreen extends StatefulWidget {
//   final String senderId;
//   final String receiverId;

//   const ChatScreen({
//     super.key,
//     required this.senderId,
//     required this.receiverId,
//   });

//   @override
//   _ChatScreenState createState() => _ChatScreenState();
// }

// class _ChatScreenState extends State<ChatScreen> {
//   final TextEditingController _controller = TextEditingController();
//   final ScrollController _scrollController =
//       ScrollController(); // ✅ Auto-scroll

//   @override
//   void initState() {
//     super.initState();
//     final chatBloc = context.read<ChatBloc>();

//     // ✅ Load Messages (Both Sent & Received)
//     chatBloc.add(LoadMessagesEvent(
//       senderId: widget.senderId,
//       receiverId: widget.receiverId,
//     ));

//     // ✅ Ensure Token is Loaded
//     if (chatBloc.state.token == null) {
//       chatBloc.add(LoadTokenEvent());
//     }
//   }

//   /// ✅ Scroll to the latest message
//   void _scrollToBottom() {
//     Future.delayed(const Duration(milliseconds: 300), () {
//       if (_scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Chat with ${widget.receiverId.substring(0, 8)}..."),
//         backgroundColor: Colors.purple,
//       ),
//       body: BlocListener<ChatBloc, ChatState>(
//         listener: (context, state) {
//           if (state.error != null) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(
//                 content: Text(state.error!),
//                 backgroundColor: Colors.red,
//               ),
//             );
//           }

//           // ✅ Auto-scroll after messages load
//           if (state.messages.isNotEmpty) {
//             _scrollToBottom();
//           }
//         },
//         child: Column(
//           children: [
//             Expanded(
//               child: BlocBuilder<ChatBloc, ChatState>(
//                 builder: (context, state) {
//                   if (state.isLoading) {
//                     return const Center(child: CircularProgressIndicator());
//                   }

//                   if (state.messages.isEmpty) {
//                     return const Center(child: Text("No messages yet"));
//                   }

//                   return ListView.builder(
//                     controller: _scrollController, // ✅ Auto-scroll enabled
//                     padding: const EdgeInsets.all(10),
//                     itemCount: state.messages.length,
//                     itemBuilder: (context, index) {
//                       final message = state.messages[index];
//                       final isSentByMe = message.senderId == widget.senderId;

//                       return Align(
//                         alignment: isSentByMe
//                             ? Alignment.centerRight
//                             : Alignment.centerLeft,
//                         child: Container(
//                           margin: const EdgeInsets.symmetric(
//                               vertical: 5, horizontal: 10),
//                           padding: const EdgeInsets.all(10),
//                           decoration: BoxDecoration(
//                             color:
//                                 isSentByMe ? Colors.purple : Colors.grey[800],
//                             borderRadius: BorderRadius.only(
//                               topLeft: const Radius.circular(10),
//                               topRight: const Radius.circular(10),
//                               bottomLeft: isSentByMe
//                                   ? const Radius.circular(10)
//                                   : Radius.zero,
//                               bottomRight: isSentByMe
//                                   ? Radius.zero
//                                   : const Radius.circular(10),
//                             ),
//                           ),
//                           child: Text(
//                             message.message,
//                             style: const TextStyle(color: Colors.white),
//                           ),
//                         ),
//                       );
//                     },
//                   );
//                 },
//               ),
//             ),

//             // ✅ Message Input Field
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Row(children: [
//                 Expanded(
//                   child: TextField(
//                     controller: _controller,
//                     decoration: InputDecoration(
//                       hintText: 'Type a message...',
//                       filled: true,
//                       fillColor: Colors.white10,
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(30),
//                         borderSide: BorderSide.none,
//                       ),
//                     ),
//                   ),
//                 ),
//                 IconButton(
//                   icon: const Icon(Icons.send, color: Colors.purple),
//                   onPressed: () {
//                     if (_controller.text.isNotEmpty) {
//                       final chatBloc = context.read<ChatBloc>();

//                       if (chatBloc.state.token == null) {
//                         ScaffoldMessenger.of(context).showSnackBar(
//                           const SnackBar(
//                             content: Text("Error: Token not available"),
//                             backgroundColor: Colors.red,
//                           ),
//                         );
//                         return;
//                       }

//                       final newMessage = MessageEntity(
//                         senderId: widget.senderId,
//                         receiverId: widget.receiverId,
//                         message: _controller.text,
//                         createdAt: DateTime.now(),
//                       );

//                       // ✅ Optimistically update the UI before API response
//                       chatBloc.add(
//                         AddOptimisticMessageEvent(newMessage),
//                       );

//                       _controller.clear();

//                       // ✅ Send the message & refresh chat
//                       chatBloc.add(
//                         SendMessage(
//                           senderId: widget.senderId,
//                           receiverId: widget.receiverId,
//                           message: newMessage.message,
//                           token: chatBloc.state.token!,
//                         ),
//                       );

//                       _scrollToBottom(); // ✅ Auto-scroll after sending
//                     }
//                   },
//                 ),
//               ]),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:koselie/features/chat/domain/entity/message_entity.dart';
// import 'package:koselie/features/chat/presentation/view_model/bloc/chat_bloc.dart';

// class ChatScreen extends StatefulWidget {
//   final String senderId;
//   final String receiverId;

//   const ChatScreen({
//     super.key,
//     required this.senderId,
//     required this.receiverId,
//   });

//   @override
//   _ChatScreenState createState() => _ChatScreenState();
// }

// class _ChatScreenState extends State<ChatScreen> {
//   final TextEditingController _controller = TextEditingController();
//   final ScrollController _scrollController = ScrollController();

//   @override
//   void initState() {
//     super.initState();
//     final chatBloc = context.read<ChatBloc>();

//     chatBloc.add(LoadMessagesEvent(
//       senderId: widget.senderId,
//       receiverId: widget.receiverId,
//     ));

//     if (chatBloc.state.token == null) {
//       chatBloc.add(LoadTokenEvent());
//     }
//   }

//   void _scrollToBottom() {
//     Future.delayed(const Duration(milliseconds: 300), () {
//       if (_scrollController.hasClients) {
//         _scrollController.animateTo(
//           _scrollController.position.maxScrollExtent,
//           duration: const Duration(milliseconds: 300),
//           curve: Curves.easeOut,
//         );
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Chat with ${widget.receiverId.substring(0, 8)}..."),
//         backgroundColor: Colors.purple,
//       ),
//       body: BlocListener<ChatBloc, ChatState>(
//         listener: (context, state) {
//           if (state.error != null) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(
//                 content: Text(state.error!),
//                 backgroundColor: Colors.red,
//               ),
//             );
//           }

//           if (state.messages.isNotEmpty) {
//             _scrollToBottom();
//           }
//         },
//         child: Column(
//           children: [
//             Expanded(
//               child: BlocBuilder<ChatBloc, ChatState>(
//                 builder: (context, state) {
//                   if (state.isLoading) {
//                     return const Center(child: CircularProgressIndicator());
//                   }

//                   if (state.messages.isEmpty) {
//                     return const Center(child: Text("No messages yet"));
//                   }

//                   return ListView.builder(
//                     controller: _scrollController,
//                     padding: const EdgeInsets.all(10),
//                     itemCount: state.messages.length,
//                     itemBuilder: (context, index) {
//                       final message = state.messages[index];
//                       final isSentByMe = message.senderId == widget.senderId;

//                       // Debugging: Print message info to console
//                       print(
//                           'Message: ${message.message}, Sender: ${message.senderId}, isSentByMe: $isSentByMe');

//                       return Align(
//                         alignment: isSentByMe
//                             ? Alignment.centerRight
//                             : Alignment.centerLeft,
//                         child: Container(
//                           margin: const EdgeInsets.symmetric(
//                               vertical: 5, horizontal: 10),
//                           padding: const EdgeInsets.all(10),
//                           decoration: BoxDecoration(
//                             color:
//                                 isSentByMe ? Colors.purple : Colors.grey[800],
//                             borderRadius: BorderRadius.only(
//                               topLeft: const Radius.circular(10),
//                               topRight: const Radius.circular(10),
//                               bottomLeft: !isSentByMe
//                                   ? const Radius.circular(10)
//                                   : Radius.zero,
//                               bottomRight: isSentByMe
//                                   ? Radius.zero
//                                   : const Radius.circular(10),
//                             ),
//                           ),
//                           child: Text(
//                             message.message,
//                             style: const TextStyle(color: Colors.white),
//                           ),
//                         ),
//                       );
//                     },
//                   );
//                 },
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: TextField(
//                       controller: _controller,
//                       decoration: InputDecoration(
//                         hintText: 'Type a message...',
//                         filled: true,
//                         fillColor: Colors.white10,
//                         border: OutlineInputBorder(
//                           borderRadius: BorderRadius.circular(30),
//                           borderSide: BorderSide.none,
//                         ),
//                       ),
//                     ),
//                   ),
//                   IconButton(
//                     icon: const Icon(Icons.send, color: Colors.purple),
//                     onPressed: () {
//                       if (_controller.text.isNotEmpty) {
//                         final chatBloc = context.read<ChatBloc>();

//                         if (chatBloc.state.token == null) {
//                           ScaffoldMessenger.of(context).showSnackBar(
//                             const SnackBar(
//                               content: Text("Error: Token not available"),
//                               backgroundColor: Colors.red,
//                             ),
//                           );
//                           return;
//                         }

//                         final newMessage = MessageEntity(
//                           senderId: widget.senderId,
//                           receiverId: widget.receiverId,
//                           message: _controller.text,
//                           createdAt: DateTime.now(),
//                         );

//                         chatBloc.add(
//                           AddOptimisticMessageEvent(newMessage),
//                         );

//                         _controller.clear();

//                         chatBloc.add(
//                           SendMessage(
//                             senderId: widget.senderId,
//                             receiverId: widget.receiverId,
//                             message: newMessage.message,
//                             token: chatBloc.state.token!,
//                           ),
//                         );

//                         _scrollToBottom();
//                       }
//                     },
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:koselie/features/chat/domain/entity/message_entity.dart';
import 'package:koselie/features/chat/presentation/view_model/bloc/chat_bloc.dart';

class ChatScreen extends StatefulWidget {
  final String senderId;
  final String receiverId;

  const ChatScreen({
    super.key,
    required this.senderId,
    required this.receiverId,
  });

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    final chatBloc = context.read<ChatBloc>();

    chatBloc.add(LoadMessagesEvent(
      senderId: widget.senderId,
      receiverId: widget.receiverId,
    ));

    if (chatBloc.state.token == null) {
      chatBloc.add(LoadTokenEvent());
    }
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 300), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chat"),
        backgroundColor: Colors.purple,
      ),
      body: BlocListener<ChatBloc, ChatState>(
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.error!),
                backgroundColor: Colors.red,
              ),
            );
          }

          _scrollToBottom();
        },
        child: Column(
          children: [
            Expanded(
              child: BlocBuilder<ChatBloc, ChatState>(
                builder: (context, state) {
                  final messages = state.messages;

                  if (state.isLoading) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (messages.isEmpty) {
                    return const Center(child: Text("No messages yet"));
                  }

                  return ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(10),
                    itemCount: messages.length,
                    itemBuilder: (context, index) {
                      final message = messages[index];
                      final isSentByMe = index == messages.length - 1;

                      return Align(
                        alignment: isSentByMe
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(
                              vertical: 5, horizontal: 10),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color:
                                isSentByMe ? Colors.purple : Colors.grey[800],
                            borderRadius: BorderRadius.only(
                              topLeft: const Radius.circular(10),
                              topRight: const Radius.circular(10),
                              bottomLeft: !isSentByMe
                                  ? const Radius.circular(10)
                                  : Radius.zero,
                              bottomRight: isSentByMe
                                  ? Radius.zero
                                  : const Radius.circular(10),
                            ),
                          ),
                          child: Text(
                            message.message,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Type a message...',
                        filled: true,
                        fillColor: Colors.white10,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(30),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.purple),
                    onPressed: () {
                      if (_controller.text.isNotEmpty) {
                        final chatBloc = context.read<ChatBloc>();

                        if (chatBloc.state.token == null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text("Error: Token not available"),
                              backgroundColor: Colors.red,
                            ),
                          );
                          return;
                        }

                        final newMessage = MessageEntity(
                          senderId: widget.senderId,
                          receiverId: widget.receiverId,
                          message: _controller.text,
                          createdAt: DateTime.now(),
                        );

                        chatBloc.add(SendMessage(
                          senderId: widget.senderId,
                          receiverId: widget.receiverId,
                          message: newMessage.message,
                          token: chatBloc.state.token!,
                        ));

                        _controller.clear();
                        _scrollToBottom();
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// part of 'chat_bloc.dart';

// abstract class ChatEvent extends Equatable {
//   const ChatEvent();

//   @override
//   List<Object?> get props => [];
// }

// /// ✅ Load Authentication Token Event
// class LoadTokenEvent extends ChatEvent {}

// /// ✅ Load Messages for a Selected Receiver
// class LoadMessagesEvent extends ChatEvent {
//   final String senderId;
//   final String receiverId;

//   const LoadMessagesEvent({
//     required this.senderId,
//     required this.receiverId,
//   });

//   @override
//   List<Object?> get props => [senderId, receiverId];
// }

// /// ✅ Send Message Event
// class SendMessage extends ChatEvent {
//   final String senderId;
//   final String receiverId;
//   final String message;

//   const SendMessage({
//     required this.senderId,
//     required this.receiverId,
//     required this.message,
//   });

//   @override
//   List<Object?> get props => [senderId, receiverId, message];
// }

// chat_event.dart
part of 'chat_bloc.dart';

abstract class ChatEvent extends Equatable {
  const ChatEvent();

  @override
  List<Object?> get props => [];
}

/// ✅ Load Authentication Token
class LoadTokenEvent extends ChatEvent {}

/// ✅ Load Messages for Selected Chat (Both Sent & Received)
class LoadMessagesEvent extends ChatEvent {
  final String senderId;
  final String receiverId;

  const LoadMessagesEvent({
    required this.senderId,
    required this.receiverId,
  });

  @override
  List<Object?> get props => [senderId, receiverId];
}

/// ✅ Add a new event for optimistically adding a message
class AddOptimisticMessageEvent extends ChatEvent {
  final MessageEntity message;

  const AddOptimisticMessageEvent(this.message);

  @override
  List<Object?> get props => [message];
}

/// ✅ Send Message Event
class SendMessage extends ChatEvent {
  final String senderId;
  final String receiverId;
  final String message;
  final String token;

  const SendMessage({
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.token,
  });

  @override
  List<Object?> get props => [senderId, receiverId, message, token];
}

// // chat_state.dart
// part of 'chat_bloc.dart';

// class ChatState extends Equatable {
//   final bool isLoading;
//   final String? token;
//   final List<MessageEntity> messages;
//   final String? error;

//   const ChatState({
//     required this.isLoading,
//     required this.token,
//     required this.messages,
//     required this.error,
//   });

//   factory ChatState.initial() {
//     return const ChatState(
//       isLoading: false,
//       token: null,
//       messages: [],
//       error: null,
//     );
//   }

//   ChatState copyWith({
//     bool? isLoading,
//     String? token,
//     List<MessageEntity>? messages,
//     String? error,
//   }) {
//     return ChatState(
//       isLoading: isLoading ?? this.isLoading,
//       token: token ?? this.token,
//       messages: messages ?? this.messages,
//       error: error ?? this.error,
//     );
//   }

//   @override
//   List<Object?> get props => [isLoading, token, messages, error];
// }

// // chat_state.dart
// part of 'chat_bloc.dart';

// class ChatState extends Equatable {
//   final String? token;
//   final List<MessageEntity> messages;
//   final bool isLoading;
//   final String? error;

//   const ChatState({
//     this.token,
//     this.messages = const [],
//     this.isLoading = false,
//     this.error,
//   });

//   factory ChatState.initial() {
//     return const ChatState(
//       token: null,
//       messages: [],
//       isLoading: false,
//       error: null,
//     );
//   }

//   ChatState copyWith({
//     String? token,
//     List<MessageEntity>? messages,
//     bool? isLoading,
//     String? error,
//   }) {
//     return ChatState(
//       token: token ?? this.token,
//       messages: messages ?? this.messages,
//       isLoading: isLoading ?? this.isLoading,
//       error: error ?? this.error,
//     );
//   }

//   @override
//   List<Object?> get props => [token, messages, isLoading, error];
// }

// chat_state.dart
part of 'chat_bloc.dart';

class ChatState extends Equatable {
  final String? token;
  final List<MessageEntity> messages;
  final bool isLoading;
  final String? error;

  const ChatState({
    this.token,
    this.messages = const [],
    this.isLoading = false,
    this.error,
  });

  /// ✅ **Initial State**
  factory ChatState.initial() {
    return const ChatState(
      token: null,
      messages: [],
      isLoading: false,
      error: null,
    );
  }

  /// ✅ **CopyWith Method**
  ChatState copyWith({
    String? token,
    List<MessageEntity>? messages,
    bool? isLoading,
    bool clearMessages = false, // ✅ Added to reset messages
    String? error,
  }) {
    return ChatState(
      token: token ?? this.token,
      messages: clearMessages ? [] : (messages ?? this.messages),
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  @override
  List<Object?> get props => [token, messages, isLoading, error];
}

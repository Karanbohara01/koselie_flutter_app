import 'package:flutter/material.dart';

class ThemeConstant {
  ThemeConstant._();
  static const Color darkPrimaryColor = Colors.pink;
  static const Color primaryColor = Colors.pink;
  static const Color appBarColor = Colors.pink;
}

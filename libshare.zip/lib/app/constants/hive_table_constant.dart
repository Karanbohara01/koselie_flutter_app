class HiveTableConstant {
  HiveTableConstant._();

  static const int authTableId = 0;
  static const String userBox = "userBox";
}

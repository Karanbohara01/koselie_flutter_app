abstract class ThemeEvent {}

class ToggleThemeEvent extends ThemeEvent {}

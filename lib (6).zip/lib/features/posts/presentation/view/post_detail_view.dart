// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:koselie/app/constants/api_endpoints.dart';
// import 'package:koselie/features/posts/presentation/view_model/posts_bloc.dart';

// class PostDetailsView extends StatefulWidget {
//   final String postId;
//   const PostDetailsView({super.key, required this.postId});

//   @override
//   _PostDetailsViewState createState() => _PostDetailsViewState();
// }

// class _PostDetailsViewState extends State<PostDetailsView> {
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       if (mounted) {
//         context.read<PostsBloc>().add(GetPostById(
//               postId: widget.postId,
//               context: context,
//             ));
//       }
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Product Details"),
//         backgroundColor: Colors.deepPurple,
//         centerTitle: true,
//         elevation: 0,
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               colors: [
//                 Color(0xFF8E2DE2), // Purple Shade
//                 Color(0xFFEC008C), // Pink Shade
//               ],
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//             ),
//           ),
//         ),
//       ),
//       body: BlocBuilder<PostsBloc, PostsState>(
//         builder: (context, state) {
//           if (state.isLoading) {
//             return const Center(child: CircularProgressIndicator());
//           } else if (state.error != null) {
//             return Center(
//               child: Text(
//                 "Error: ${state.error!}",
//                 style: const TextStyle(color: Colors.red, fontSize: 16),
//                 textAlign: TextAlign.center,
//               ),
//             );
//           } else if (state.selectedPost == null) {
//             return const Center(child: Text("Post not found"));
//           }

//           final post = state.selectedPost!;

//           return SingleChildScrollView(
//             child: Padding(
//               padding: const EdgeInsets.all(16.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   // 🖼 Image Display
//                   Hero(
//                     tag: 'post-image-${post.postId}',
//                     child: Container(
//                       decoration: BoxDecoration(
//                         boxShadow: [
//                           BoxShadow(
//                             color: Colors.black.withOpacity(0.2),
//                             blurRadius: 6,
//                             spreadRadius: 2,
//                             offset: const Offset(0, 3),
//                           ),
//                         ],
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       child: ClipRRect(
//                         borderRadius: BorderRadius.circular(12),
//                         child: post.image != null && post.image!.isNotEmpty
//                             ? Image.network(
//                                 "${ApiEndpoints.imageUrl}/${post.image!}",
//                                 width: double.infinity,
//                                 height: 250,
//                                 fit: BoxFit.cover,
//                                 errorBuilder: (context, error, stackTrace) =>
//                                     _buildPlaceholderImage(),
//                               )
//                             : _buildPlaceholderImage(),
//                       ),
//                     ),
//                   ),

//                   const SizedBox(height: 16),

//                   // 🏷️ Product Title
//                   Text(
//                     post.caption,
//                     style: const TextStyle(
//                       fontSize: 24,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.deepPurple,
//                     ),
//                   ),

//                   const SizedBox(height: 8),

//                   // 💰 Price Display
//                   Text(
//                     "Rs. ${post.price}",
//                     style: const TextStyle(
//                       fontSize: 22,
//                       color: Colors.green,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),

//                   const SizedBox(height: 8),

//                   // 📍 Location
//                   Row(
//                     children: [
//                       const Icon(Icons.location_on, color: Colors.red),
//                       const SizedBox(width: 4),
//                       Text(
//                         post.location,
//                         style:
//                             const TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),

//                   const SizedBox(height: 16),

//                   // 📄 Description
//                   Text(
//                     post.description,
//                     style: const TextStyle(fontSize: 16, color: Colors.black87),
//                   ),

//                   const SizedBox(height: 16),

//                   // 🔖 Category
//                   if (post.category.name.isNotEmpty)
//                     Text(
//                       post.category.name,
//                       style: const TextStyle(color: Colors.red),
//                     ),
//                   // ❤️ Likes & Comments
//                   const Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     children: [
//                       Row(
//                         children: [
//                           Icon(Icons.favorite, color: Colors.red),
//                           SizedBox(width: 4),
//                           Text("4 Likes", style: TextStyle(color: Colors.grey)),
//                         ],
//                       ),
//                       Row(
//                         children: [
//                           Icon(Icons.comment, color: Colors.blueAccent),
//                           SizedBox(width: 4),
//                           Text("2 Comments",
//                               style: TextStyle(color: Colors.grey)),
//                         ],
//                       ),
//                     ],
//                   ),

//                   const SizedBox(height: 16),

//                   // 🛒 Call to Action (Buy Now, Message Seller)
//                   Row(
//                     children: [
//                       Expanded(
//                         child: ElevatedButton(
//                           onPressed: () {},
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.green,
//                             padding: const EdgeInsets.symmetric(vertical: 14),
//                             shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(8)),
//                           ),
//                           child: const Text(
//                             "Buy Now",
//                             style: TextStyle(fontSize: 16, color: Colors.white),
//                           ),
//                         ),
//                       ),
//                       const SizedBox(width: 10),
//                       Expanded(
//                         child: ElevatedButton(
//                           onPressed: () {
//                             // Implement Chat with Seller
//                           },
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.blueAccent,
//                             padding: const EdgeInsets.symmetric(vertical: 14),
//                             shape: RoundedRectangleBorder(
//                                 borderRadius: BorderRadius.circular(8)),
//                           ),
//                           child: const Text(
//                             "Message Seller",
//                             style: TextStyle(fontSize: 16, color: Colors.white),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }

//   // Placeholder image for posts without an image
//   Widget _buildPlaceholderImage() {
//     return Container(
//       height: 250,
//       color: Colors.grey[300],
//       child: const Center(
//         child: Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:koselie/app/constants/api_endpoints.dart';
import 'package:koselie/core/common/snackbar/snackbar.dart';
import 'package:koselie/features/auth/presentation/view_model/login/login_bloc.dart';
import 'package:koselie/features/chat/presentation/view/chat_view.dart';
import 'package:koselie/features/posts/presentation/view_model/posts_bloc.dart';

class PostDetailsView extends StatefulWidget {
  final String postId;
  const PostDetailsView({super.key, required this.postId});

  @override
  _PostDetailsViewState createState() => _PostDetailsViewState();
}

class _PostDetailsViewState extends State<PostDetailsView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<PostsBloc>().add(GetPostById(
              postId: widget.postId,
              context: context,
            ));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Product Details"),
        centerTitle: true,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF8E2DE2), // Purple Shade
                Color(0xFFEC008C), // Pink Shade
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
      ),
      body: BlocBuilder<PostsBloc, PostsState>(
        builder: (context, state) {
          if (state.isLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state.error != null) {
            return Center(
              child: Text(
                "Error: ${state.error!}",
                style: const TextStyle(color: Colors.red, fontSize: 16),
                textAlign: TextAlign.center,
              ),
            );
          } else if (state.selectedPost == null) {
            return const Center(child: Text("Post not found"));
          }

          final post = state.selectedPost!;

          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 🖼 Image Display
                  Hero(
                    tag: 'post-image-${post.postId}',
                    child: Container(
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 6,
                            spreadRadius: 2,
                            offset: const Offset(0, 3),
                          ),
                        ],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: post.image != null && post.image!.isNotEmpty
                            ? Image.network(
                                "${ApiEndpoints.imageUrl}/${post.image!}",
                                width: double.infinity,
                                height: 250,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    _buildPlaceholderImage(),
                              )
                            : _buildPlaceholderImage(),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // 🏷️ Product Title
                  Text(
                    post.caption,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepPurple,
                    ),
                  ),

                  const SizedBox(height: 8),

                  // 💰 Price Display
                  Text(
                    "Rs. ${post.price}",
                    style: const TextStyle(
                      fontSize: 22,
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 8),

                  // 📍 Location
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Colors.red),
                      const SizedBox(width: 4),
                      Text(
                        post.location,
                        style:
                            const TextStyle(fontSize: 16, color: Colors.grey),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // 📄 Description
                  Text(
                    post.description,
                    style: const TextStyle(fontSize: 16, color: Colors.black87),
                  ),

                  const SizedBox(height: 16),

                  // 🔖 Category
                  if (post.category.name.isNotEmpty)
                    Chip(
                      label: Text(
                        post.category.name,
                        style: const TextStyle(color: Colors.white),
                      ),
                      backgroundColor: Colors.purpleAccent,
                    ),

                  const SizedBox(height: 16),

                  // ❤️ Likes & Comments
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.favorite, color: Colors.red),
                          SizedBox(width: 4),
                          Text("4 Likes", style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(Icons.comment, color: Colors.blueAccent),
                          SizedBox(width: 4),
                          Text("2 Comments",
                              style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // 🛒 Call to Action (Buy Now, Message Seller)
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8)),
                          ),
                          child: const Text(
                            "Buy Now",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () => _navigateToChatScreen(context, post),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueAccent,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8)),
                          ),
                          child: const Text(
                            "Message Seller",
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _navigateToChatScreen(BuildContext context, var post) {
    final loggedInUser = context.read<LoginBloc>().state.user;

    if (loggedInUser == null) {
      showMySnackBar(
        context: context,
        message: "Error: You must be logged in to chat!",
        color: Colors.red,
      );
      return;
    }

    if (post.author == null || post.author['username'] == null) {
      showMySnackBar(
        context: context,
        message: "Error: Seller information is missing!",
        color: Colors.red,
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreen(
          senderId: loggedInUser.userId!,
          receiverId: post.author['_id'],
          receiverUsername: post.author['username'],
          receiverImage: post.author['image'] ?? '',
          key: ValueKey(post.author['_id']),
        ),
      ),
    );
  }

  Widget _buildPlaceholderImage() {
    return Container(
      height: 250,
      color: Colors.grey[300],
      child: const Center(
        child: Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
      ),
    );
  }
}

// class CommentEntity {
//   final String id;
//   final String username;
//   final String text;

//   CommentEntity({
//     required this.id,
//     required this.username,
//     required this.text,
//   });

//   factory CommentEntity.fromJson(Map<String, dynamic> json) {
//     return CommentEntity(
//       id: json['_id'],
//       username: json['username'],
//       text: json['text'],
//     );
//   }

//   Map<String, dynamic> toJson() {
//     return {
//       '_id': id,
//       'username': username,
//       'text': text,
//     };
//   }
// }

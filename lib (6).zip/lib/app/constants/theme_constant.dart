import 'package:flutter/material.dart';

class ThemeConstant {
  ThemeConstant._();
  static const Color darkPrimaryColor = Colors.black;
  static const Color primaryColor = Colors.black;
  static const Color appBarColor = Colors.black;
}

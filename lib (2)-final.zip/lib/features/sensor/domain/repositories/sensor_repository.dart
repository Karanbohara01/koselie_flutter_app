abstract class SensorRepository {
  Stream<bool> detectShake();
}

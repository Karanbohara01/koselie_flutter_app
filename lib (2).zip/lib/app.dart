// import 'package:flutter/material.dart';
// import 'package:koselie/view/splash_screen_view.dart';

// void main() {
//   runApp(const MyApp());
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const MaterialApp(
//       debugShowCheckedModeBanner: false, // Disable debug banner
//       title: 'Koselie',
//       // theme: getApplicationTheme(),
//       home: SplashScreen(), // Set the initial screen to SplashScreen
//     );
//   }
// }

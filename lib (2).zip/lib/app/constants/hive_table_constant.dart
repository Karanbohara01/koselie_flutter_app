class HiveTableConstant {
  HiveTableConstant._();

  static const int authTableId = 0;
  static const String userBox = "userBox";
  static const int postTableId = 1;
  static const String postBox = 'postBox';
  static const int categoryTableId = 2;
  static const String categoryBox = 'categoryBox';
}

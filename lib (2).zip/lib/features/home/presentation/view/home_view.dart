// import 'package:flutter/material.dart';
// import 'package:koselie/features/category/presentation/view/category_view.dart';
// import 'package:koselie/features/dashboard/presentation/view/dashboard_view.dart';
// import 'package:koselie/features/posts/presentation/view/create_post_view.dart';
// import 'package:koselie/features/posts/presentation/view/get_all_posts_view.dart';

// class HomeView extends StatefulWidget {
//   const HomeView({super.key});

//   @override
//   State<HomeView> createState() => _MyHomeViewState();
// }

// class _MyHomeViewState extends State<HomeView> {
//   int _selectedIndex = 0;

//   // List of bottom navigation screens
//   List<Widget> lstBOttomScreen = [
//     const DashboardScreen(),
//     // const MarketScreen(),
//     const CreatePostView(),
//     // const ProfileScreen(),
//     const PostView(),
//     CategoryView(),
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return SafeArea(
//       child: Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.pink,
//           centerTitle: true,
//         ),
//         body: lstBOttomScreen[_selectedIndex], // Display the selected screen
//         bottomNavigationBar: BottomNavigationBar(
//           type: BottomNavigationBarType.fixed,
//           selectedItemColor: Colors.white,
//           backgroundColor: Colors.pink,
//           items: const [
//             BottomNavigationBarItem(
//               icon: Icon(Icons.home),
//               label: 'Dashboard',
//             ),
//             BottomNavigationBarItem(
//                 icon: Icon(
//                   Icons.add,
//                 ),
//                 label: 'Post'),
//             BottomNavigationBarItem(
//                 icon: Icon(
//                   Icons.sell,
//                 ),
//                 label: 'Market'),
//             BottomNavigationBarItem(
//                 icon: Icon(
//                   Icons.category,
//                 ),
//                 label: 'Category'),
//           ],
//           currentIndex: _selectedIndex,
//           onTap: (index) {
//             setState(() {
//               _selectedIndex = index; // Update the index to switch screens
//             });
//           },
//         ),
//       ),
//     );
//   }
// }

// // Define placeholder screens for Market, Profile, and Search

import 'package:flutter/material.dart';
import 'package:koselie/features/category/presentation/view/category_view.dart';
import 'package:koselie/features/dashboard/presentation/view/dashboard_view.dart';
import 'package:koselie/features/posts/presentation/view/create_post_view.dart';
import 'package:koselie/features/posts/presentation/view/get_all_posts_view.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});
  @override
  State<HomeView> createState() => _MyHomeViewState();
}

class _MyHomeViewState extends State<HomeView> {
  int _selectedIndex = 0;

  // List of bottom navigation screens
  List<Widget> lstBOttomScreen = [
    const DashboardScreen(),
    const CreatePostView(),
    const PostView(), // Corrected this line
    CategoryView(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: lstBOttomScreen[_selectedIndex], // Display the selected screen
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.white, // A more typical selected color
        unselectedItemColor: Colors.black,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home', // More common label for the dashboard
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            label: 'Post', // Simpler label than 'Post'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shop), // More accurate icon for "Market"
            label: 'Market', // Standard label
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.category),
            label: 'Category',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index; // Update the index to switch screens
          });
        },
      ),
    );
  }
}
